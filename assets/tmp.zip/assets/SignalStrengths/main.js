var main = {};


(function() {

var listener = {};

var rat = plt.types.Rational.makeInstance;


listener.orientUpdate = function(azimuth, pitch, roll) {
  plt.world.config.CONFIG.lookup('changeWorld')(function(w) {
     if (plt.world.config.CONFIG.lookup('onTiltEffect')) {
         var effect = plt.world.config.CONFIG.lookup('onTiltEffect')([w, rat(azimuth, 1), rat(pitch, 1), rat(roll, 1)]);
         plt.world.Kernel.applyEffect(effect);
     }

     if (plt.world.config.CONFIG.lookup('onTilt')) {
         return plt.world.config.CONFIG.lookup('onTilt')([w, rat(azimuth, 1), rat(pitch, 1), rat(roll, 1)]);
     } else {
         return w;
     }
  });
};

listener.accelUpdate = function(x, y, z) {
  plt.world.config.CONFIG.lookup('changeWorld')(function(w) {
      if (plt.world.config.CONFIG.lookup('onAccelerationEffect')) {
          var effect = plt.world.config.CONFIG.lookup('onAccelerationEffect')([w, rat(x, 1), rat(y, 1), rat(z, 1)]);
          plt.world.Kernel.applyEffect(effect);
      }
   
      if (plt.world.config.CONFIG.lookup('onAcceleration')) {
          return plt.world.config.CONFIG.lookup('onAcceleration')([w, rat(x, 1), rat(y, 1), rat(z, 1)]);
      } else {
          return w;
      }
  });
};

listener.shakeUpdate = function() {
  var onShake = plt.world.config.CONFIG.lookup('onShake');
  var onShakeEffect = plt.world.config.CONFIG.lookup('onShakeEffect');
  if (onShake) {
     plt.world.config.CONFIG.lookup('changeWorld')(function(w) {

       if (onShakeEffect) { 
           var effect = onShakeEffect([w]);
           plt.world.Kernel.applyEffect(effect);
       }

       return onShake([w]);
    });
  }
};

listener.locUpdate = function(lat, lng) {
  var onLocationChange = plt.world.config.CONFIG.lookup('onLocationChange');
  var onLocationChangeEffect = plt.world.config.CONFIG.lookup('onLocationChangeEffect');

  if (onLocationChange) {
    plt.world.config.CONFIG.lookup('changeWorld')(function(w) {

      if (onLocationChangeEffect) {
          var effect = onLocationChangeEffect([w, rat(lat), rat(lng)]);
          plt.world.Kernel.applyEffect(effect);
      }
      return onLocationChange([w, rat(lat), rat(lng)]);
    });
  }
};


main.startup = function() {


};

main.shutdown = function() {

};


main.destroy = function() {

};


// Waits until all images are loaded, after which we
// evaluate the after thunk.
main.afterPreloadImages = function(after) {
  var imagePaths = [];
  var images = [];
  function wait(predicate, after) {
      if (predicate()) 
	  after();
      else
	  setTimeout(function() { wait(predicate, after); },
		     100);
  }

  function isAllLoaded() {
      var i;
      for (i = 0; i < images.length; i++) {
	  if (! (images[i].isLoaded)) {
	      return false;
	  }
      }
      return true;
  }

  var i;
  for (i = 0; i < imagePaths.length; i++) {
      images.push(plt.world.Kernel._kernelCreateImage
		  (plt.types.String.makeInstance(imagePaths[i])));
  }
  wait(isAllLoaded, after);
};


main.runToplevel = function() {
   ((function (toplevel_dash_expression_dash_show0) { 

initial_dash_world = plt.types.Empty.EMPTY;




toplevel_dash_expression_dash_show0(plt.world.MobyJsworld.bigBang(initial_dash_world,plt.types.Empty.EMPTY, [(plt.world.config.Kernel.onDraw((function() { var result = (function(args) {
                    return draw(args[0]);
                 }); result.toWrittenString = function() {return '<primitive:draw>'; }
                     result.toDisplayedString = function() {return '<primitive:draw>';}
                     return result; })(),(function() { var result = (function(args) {
                    return draw_dash_css();
                 }); result.toWrittenString = function() {return '<primitive:draw-css>'; }
                     result.toDisplayedString = function() {return '<primitive:draw-css>';}
                     return result; })())),(plt.world.config.Kernel.onTick((plt.types.Rational.makeInstance(30, 1)),(function() { var result = (function(args) {
                    return update(args[0]);
                 }); result.toWrittenString = function() {return '<primitive:update>'; }
                     result.toDisplayedString = function() {return '<primitive:update>';}
                     return result; })()))])); }))(plt.Kernel.identity);
};


// Module require erased

function tower(id,strength) { this.id = id;
this.strength = strength; }
                    tower.prototype = new plt.Kernel.Struct();
tower.prototype.toWrittenString = function() { 
                               return '(' + ['make-tower',this.id.toWrittenString(),this.strength.toWrittenString()].join(' ') + ')'; };tower.prototype.toDisplayedString = tower.prototype.toWrittenString;

tower.prototype.isEqual = function(other) {
              if (other instanceof tower) {
                return ((plt.Kernel.equal_question_((tower_dash_strength(this)),(tower_dash_strength(other))))&&((plt.Kernel.equal_question_((tower_dash_id(this)),(tower_dash_id(other))))&&plt.types.Logic.TRUE));
              } else {
                return false;
              }
           } 
function make_dash_tower(id0,id1) { return new tower(id0,id1); }
function tower_dash_id(obj) { return obj.id; }
function tower_dash_strength(obj) { return obj.strength; }
function tower_question_(obj) { 
              return obj instanceof tower; }
var initial_dash_world; 
function update(w) { return ((function() { 

var infos; 
function info_dash__greaterthan_tower(an_dash_info) { return (make_dash_tower((plt.Kernel.first(an_dash_info)),(plt.Kernel.second(an_dash_info)))); }
(function (toplevel_dash_expression_dash_show1) { 
infos = (plt.lib.Telephony.getSignalStrengths());
 })(plt.Kernel.identity)
return plt.Kernel.map((function() { var result = (function(args) {
                    return info_dash__greaterthan_tower(args[0]);
                 }); result.toWrittenString = function() {return '<primitive:info->tower>'; }
                     result.toDisplayedString = function() {return '<primitive:info->tower>';}
                     return result; })(), [infos]);
              })()); }
function tower_dash__greaterthan_string(a_dash_tower) { return plt.Kernel.string_dash_append([(plt.Kernel.number_dash__greaterthan_string((tower_dash_id(a_dash_tower)))),(plt.types.String.makeInstance(" ")),(plt.Kernel.number_dash__greaterthan_string((tower_dash_strength(a_dash_tower))))]); }
function draw(w) { return ((function() { 

function tower_dash__greaterthan_node(a_dash_tower) { return plt.Kernel.list([plt.world.MobyJsworld.text((tower_dash__greaterthan_string(a_dash_tower)), [])]); }
(function (toplevel_dash_expression_dash_show2) { 
 })(plt.Kernel.identity)
return plt.Kernel.list([plt.world.MobyJsworld.p([]),plt.Kernel.list([plt.world.MobyJsworld.text((plt.types.String.makeInstance("I see the following towers.")), [])]),(plt.Kernel.cons(plt.world.MobyJsworld.p([]),plt.Kernel.map((function() { var result = (function(args) {
                    return tower_dash__greaterthan_node(args[0]);
                 }); result.toWrittenString = function() {return '<primitive:tower->node>'; }
                     result.toDisplayedString = function() {return '<primitive:tower->node>';}
                     return result; })(), [w]))),plt.Kernel.list([plt.world.MobyJsworld.button((function() { var result = (function(args) {
                    return update(args[0]);
                 }); result.toWrittenString = function() {return '<primitive:update>'; }
                     result.toDisplayedString = function() {return '<primitive:update>';}
                     return result; })(), []),plt.Kernel.list([plt.world.MobyJsworld.text((plt.types.String.makeInstance("Update!")), [])])])]);
              })()); }
function draw_dash_css() { return plt.types.Empty.EMPTY; }



})();
